# SolPad – Solana Token Launchpad

## 🔗 Live Demo
https://solpad.vercel.app

## ⚙️ Installation
```bash
git clone https://github.com/gurwinder-gg/SolPad.git
cd SolPad
npm install
npm run dev
```

## ✨ Features
- Create SPL Tokens on Solana
- Free and Premium tiers
- Arweave metadata storage (Premium)
- Wallet Adapter Integration

## 💻 Tech Stack
React, Tailwind, TypeScript, Solana Web3, Metaplex